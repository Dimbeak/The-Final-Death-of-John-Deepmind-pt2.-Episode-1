Make sure that: 
	- deepmind_prequel.rad is in the same directory as your compile tools;
	- the contents are left in the directory that came in the archive to avoid naming conflicts;
	- the compile parameters used are the same as in compile_params.txt;
	- the compile parameters are in a separate compile configuration if you're using J.A.C.K.;